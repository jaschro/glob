(function () {
  "use strict";

  var root = document.getElementById("browse-root");
  if (!root) return;

  var els = {
    categoryTree: document.getElementById("category-tree"),
    dateTree: document.getElementById("date-tree"),
    results: document.getElementById("browse-results"),
    empty: document.getElementById("browse-empty"),
    emptyClearBtn: document.getElementById("empty-clear-btn"),
    status: document.getElementById("browse-status"),
    searchForm: document.getElementById("browse-search-form"),
    searchInput: document.getElementById("browse-search-input"),
    clearAllBtn: document.getElementById("clear-all"),
    categoryClearBtn: document.querySelector('[data-clear="category"]'),
    dateClearBtn: document.querySelector('[data-clear="date"]')
  };

  var MONTH_NAMES = ["Jan", "Feb", "Mar", "Apr", "May", "Jun",
    "Jul", "Aug", "Sep", "Oct", "Nov", "Dec"];

  var state = readStateFromURL();
  var allItems = [];

  fetch(root.getAttribute("data-json-url"))
    .then(function (res) {
      if (!res.ok) throw new Error("Fetch failed: " + res.status);
      return res.json();
    })
    .then(function (data) {
      allItems = Array.isArray(data) ? data : [];
      buildCategoryTree(allItems);
      buildDateTree(allItems);
      if (els.searchInput) els.searchInput.value = state.q || "";
      render();
    })
    .catch(function (err) {
      // Fail gracefully -- never leave the page looking broken.
      if (els.status) {
        els.status.textContent = "Couldn't load posts right now. Try refreshing.";
      }
      if (els.categoryTree) els.categoryTree.innerHTML = "";
      if (els.dateTree) els.dateTree.innerHTML = "";
      console.error(err);
    });

  function readStateFromURL() {
    var params = new URLSearchParams(window.location.search);
    return {
      category: params.get("category") || "",
      subcategory: params.get("subcategory") || "",
      year: params.get("year") || "",
      month: params.get("month") || "",
      q: params.get("q") || ""
    };
  }

  function writeStateToURL() {
    var params = new URLSearchParams();
    if (state.category) params.set("category", state.category);
    if (state.subcategory) params.set("subcategory", state.subcategory);
    if (state.year) params.set("year", state.year);
    if (state.month) params.set("month", state.month);
    if (state.q) params.set("q", state.q);
    var qs = params.toString();
    var newURL = window.location.pathname + (qs ? "?" + qs : "");
    window.history.replaceState(null, "", newURL);
  }

  function buildCategoryTree(items) {
    if (!els.categoryTree) return;
    var tree = {}; // category -> { count, subs: { subcat -> count } }

    items.forEach(function (item) {
      var cats = item.categories || [];
      cats.forEach(function (cat) {
        if (!tree[cat]) tree[cat] = { count: 0, subs: {} };
        tree[cat].count++;
        if (item.subcategory) {
          tree[cat].subs[item.subcategory] = (tree[cat].subs[item.subcategory] || 0) + 1;
        }
      });
    });

    var catNames = Object.keys(tree).sort();
    els.categoryTree.innerHTML = "";

    if (catNames.length === 0) {
      els.categoryTree.innerHTML = '<li class="filter-tree-empty">No categories yet</li>';
      return;
    }

    catNames.forEach(function (cat) {
      var li = document.createElement("li");
      var link = makeFilterLink(cat + " (" + tree[cat].count + ")", cat === state.category && !state.subcategory,
        function () {
          state.category = (state.category === cat && !state.subcategory) ? "" : cat;
          state.subcategory = "";
          afterFilterChange();
        });
      li.appendChild(link);

      var subNames = Object.keys(tree[cat].subs).sort();
      if (subNames.length) {
        var subUl = document.createElement("ul");
        subUl.className = "filter-subtree";
        subNames.forEach(function (sub) {
          var subLi = document.createElement("li");
          var active = state.category === cat && state.subcategory === sub;
          var subLink = makeFilterLink(sub + " (" + tree[cat].subs[sub] + ")", active, function () {
            if (state.category === cat && state.subcategory === sub) {
              state.category = "";
              state.subcategory = "";
            } else {
              state.category = cat;
              state.subcategory = sub;
            }
            afterFilterChange();
          });
          subLi.appendChild(subLink);
          subUl.appendChild(subLi);
        });
        li.appendChild(subUl);
      }

      els.categoryTree.appendChild(li);
    });
  }

  function buildDateTree(items) {
    if (!els.dateTree) return;
    var tree = {}; // year -> { count, months: { month -> count } }

    items.forEach(function (item) {
      if (!item.date) return;
      var parts = item.date.split("-");
      var year = parts[0];
      var month = parts[1];
      if (!tree[year]) tree[year] = { count: 0, months: {} };
      tree[year].count++;
      tree[year].months[month] = (tree[year].months[month] || 0) + 1;
    });

    var years = Object.keys(tree).sort().reverse();
    els.dateTree.innerHTML = "";

    if (years.length === 0) {
      els.dateTree.innerHTML = '<li class="filter-tree-empty">No dated items yet</li>';
      return;
    }

    years.forEach(function (year) {
      var li = document.createElement("li");
      var link = makeFilterLink(year + " (" + tree[year].count + ")", year === state.year && !state.month,
        function () {
          state.year = (state.year === year && !state.month) ? "" : year;
          state.month = "";
          afterFilterChange();
        });
      li.appendChild(link);

      var months = Object.keys(tree[year].months).sort();
      if (months.length > 1) {
        var monthUl = document.createElement("ul");
        monthUl.className = "filter-subtree";
        months.forEach(function (month) {
          var label = (MONTH_NAMES[parseInt(month, 10) - 1] || month) + " (" + tree[year].months[month] + ")";
          var active = state.year === year && state.month === month;
          var monthLink = makeFilterLink(label, active, function () {
            if (state.year === year && state.month === month) {
              state.year = "";
              state.month = "";
            } else {
              state.year = year;
              state.month = month;
            }
            afterFilterChange();
          });
          var monthLi = document.createElement("li");
          monthLi.appendChild(monthLink);
          monthUl.appendChild(monthLi);
        });
        li.appendChild(monthUl);
      }

      els.dateTree.appendChild(li);
    });
  }

  function makeFilterLink(label, active, onClick) {
    var a = document.createElement("a");
    a.href = "#";
    a.textContent = label;
    a.className = "filter-link" + (active ? " active" : "");
    a.addEventListener("click", function (e) {
      e.preventDefault();
      onClick();
    });
    return a;
  }

  function afterFilterChange() {
    writeStateToURL();
    buildCategoryTree(allItems);
    buildDateTree(allItems);
    render();
  }

  function matches(item) {
    if (state.category) {
      var cats = item.categories || [];
      if (cats.indexOf(state.category) === -1) return false;
    }
    if (state.subcategory && item.subcategory !== state.subcategory) return false;
    if (state.year) {
      var itemYear = (item.date || "").split("-")[0];
      if (itemYear !== state.year) return false;
    }
    if (state.month) {
      var itemMonth = (item.date || "").split("-")[1];
      if (itemMonth !== state.month) return false;
    }
    if (state.q) {
      var needle = state.q.toLowerCase();
      var haystack = [item.title, item.subcategory, item.type]
        .concat(item.categories || [])
        .filter(Boolean)
        .join(" ")
        .toLowerCase();
      if (haystack.indexOf(needle) === -1) return false;
    }
    return true;
  }

  function render() {
    var filtered = allItems.filter(matches);

    toggleClearButtons();

    if (els.status) {
      var count = filtered.length;
      els.status.textContent = allItems.length
        ? (count + " item" + (count === 1 ? "" : "s"))
        : "";
    }

    if (!els.results) return;
    els.results.innerHTML = "";

    if (filtered.length === 0) {
      els.results.hidden = true;
      if (els.empty) els.empty.hidden = false;
      return;
    }

    if (els.empty) els.empty.hidden = true;
    els.results.hidden = false;

    filtered.forEach(function (item) {
      var li = document.createElement("li");
      li.className = "post-stream-item";

      var time = document.createElement("time");
      time.setAttribute("datetime", item.date || "");
      time.textContent = formatDate(item.date);
      li.appendChild(time);

      var a = document.createElement("a");
      a.href = item.url;
      a.textContent = item.title;
      li.appendChild(a);

      els.results.appendChild(li);
    });
  }

  function toggleClearButtons() {
    var anyCategory = !!(state.category || state.subcategory);
    var anyDate = !!(state.year || state.month);
    var any = anyCategory || anyDate || !!state.q;

    if (els.categoryClearBtn) els.categoryClearBtn.hidden = !anyCategory;
    if (els.dateClearBtn) els.dateClearBtn.hidden = !anyDate;
    if (els.clearAllBtn) els.clearAllBtn.hidden = !any;
  }

  function formatDate(iso) {
    if (!iso) return "";
    var parts = iso.split("-");
    if (parts.length !== 3) return iso;
    var month = MONTH_NAMES[parseInt(parts[1], 10) - 1] || parts[1];
    return month + " " + parseInt(parts[2], 10) + ", " + parts[0];
  }

  function clearCategory() {
    state.category = "";
    state.subcategory = "";
    afterFilterChange();
  }

  function clearDate() {
    state.year = "";
    state.month = "";
    afterFilterChange();
  }

  function clearAll() {
    state.category = "";
    state.subcategory = "";
    state.year = "";
    state.month = "";
    state.q = "";
    if (els.searchInput) els.searchInput.value = "";
    afterFilterChange();
  }

  if (els.categoryClearBtn) els.categoryClearBtn.addEventListener("click", clearCategory);
  if (els.dateClearBtn) els.dateClearBtn.addEventListener("click", clearDate);
  if (els.clearAllBtn) els.clearAllBtn.addEventListener("click", clearAll);
  if (els.emptyClearBtn) els.emptyClearBtn.addEventListener("click", clearAll);

  if (els.searchForm) {
    els.searchForm.addEventListener("submit", function (e) {
      e.preventDefault();
    });
  }
  if (els.searchInput) {
    els.searchInput.addEventListener("input", function () {
      state.q = els.searchInput.value.trim();
      writeStateToURL();
      render();
    });
  }
})();
